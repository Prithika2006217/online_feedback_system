from django.db import models

class Feedback(models.Model):
    SECTION_CHOICES = [
        ('CSE-A', 'CSE-A'), ('CSE-B', 'CSE-B'), ('CSE-C', 'CSE-C'),
        ('CSM-A', 'CSM-A'), ('CSM-B', 'CSM-B'), ('CSM-C', 'CSM-C'),
        ('CSD', 'CSD'), ('CSC', 'CSC'),
        ('ECE-A', 'ECE-A'), ('ECE-B', 'ECE-B'), ('ECE-C', 'ECE-C')
    ]

    SUBJECTS = {
        'CSE': ['ODE', 'AP', 'ESE', 'EDC', 'PYTHON'],
        'CSM': ['ODE', 'EC', 'BEE', 'EDC', 'CAD', 'PYTHON'],
        'ECE': ['ODE', 'EC', 'BEE', 'EDC', 'CAD', 'PYTHON'],
        'CSD': ['ODE', 'AP', 'ESE', 'EDC', 'PYTHON'],
        'CSC': ['ODE', 'AP', 'ESE', 'EDC', 'PYTHON']
    }

    section = models.CharField(max_length=10, choices=SECTION_CHOICES)
    ratings = models.JSONField(default=dict)
    suggestion = models.TextField(blank=True, null=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.section} - {self.submitted_at.strftime('%Y-%m-%d')}"
    
    def get_subjects(self):
        branch = self.section.split('-')[0] if '-' in self.section else self.section
        return self.SUBJECTS.get(branch, [])
    
    def get_average_rating(self):
        if not self.ratings:
            return 0.0
        total = count = 0
        for subject_ratings in self.ratings.values():
            if isinstance(subject_ratings, dict):
                for rating in subject_ratings.values():
                    try:
                        total += int(rating)
                        count += 1
                    except (ValueError, TypeError):
                        continue
        return round(total / count, 2) if count > 0 else 0.0