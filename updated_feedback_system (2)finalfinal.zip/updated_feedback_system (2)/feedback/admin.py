from django.contrib import admin
from django.utils.safestring import mark_safe
from .models import Feedback

class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['section', 'submitted_at']
    list_filter = ['section']
    change_list_template = 'admin/section_analytics.html'
    
    def changelist_view(self, request, extra_context=None):
        # Get section from URL parameters
        section = request.GET.get('section')
        
        if not section:
            # Show section selection if no section specified
            sections = set(Feedback.objects.values_list('section', flat=True))
            return super().changelist_view(request, {
                'sections': sorted(sections),
                'show_selector': True
            })
        
        # Get all feedback for this section
        feedbacks = Feedback.objects.filter(section=section)
        
        # Get all subjects from the feedbacks
        subjects = set()
        for fb in feedbacks:
            subjects.update(fb.ratings.keys())
        subjects = sorted(subjects)
        
        # Prepare questions
        questions = [
            (1, "Syllabus Coverage"),
            (2, "Teacher Preparation"),
            (3, "Communication"),
            (4, "Teaching Approach"),
            (5, "Evaluation Fairness"),
            (6, "Competencies Info"),
            (7, "Examples Provided"),
            (8, "Strengths Identified"),
            (9, "Weaknesses Addressed"),
            (10, "Extracurricular Encouragement"),
            (11, "Overall Quality")
        ]
        
        # Calculate averages for each subject-question pair
        subject_stats = {}
        suggestions = []
        
        for fb in feedbacks:
            # Collect suggestions
            if fb.suggestion:
                suggestions.append(fb)
            
            # Process ratings
            for subject, ratings in fb.ratings.items():
                if subject not in subject_stats:
                    subject_stats[subject] = {f'q{q_num}': [] for q_num, _ in questions}
                
                for q_num, _ in questions:
                    rating = ratings.get(f'q{q_num}')
                    if rating:
                        subject_stats[subject][f'q{q_num}'].append(int(rating))
        
        # Prepare matrix data for template
        averages_matrix = []
        for q_num, q_text in questions:
            row = {
                'question': f"Q{q_num}: {q_text}",
                'scores': []
            }
            for subject in subjects:
                ratings = subject_stats[subject][f'q{q_num}']
                avg = sum(ratings)/len(ratings) if ratings else 0
                row['scores'].append(round(avg, 1))
            averages_matrix.append(row)
        
        # Prepare context
        context = {
            'section': section,
            'subjects': subjects,
            'averages_matrix': averages_matrix,
            'suggestions': sorted(suggestions, key=lambda x: x.submitted_at, reverse=True),
            'show_selector': False
        }
        
        return super().changelist_view(request, extra_context=context)

admin.site.register(Feedback, FeedbackAdmin)