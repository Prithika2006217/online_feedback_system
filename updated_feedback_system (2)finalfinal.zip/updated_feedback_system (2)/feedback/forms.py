from django import forms
from .models import Feedback

class SectionForm(forms.Form):
    section = forms.ChoiceField(
        choices=Feedback.SECTION_CHOICES,
        label="Select Your Section",
        widget=forms.Select(attrs={
            'class': 'form-control',
            'required': 'required'
        })
    )

class FeedbackForm(forms.Form):
    def __init__(self, subjects, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.subjects = subjects
        
        # Define the rating choices (1-5 scale)
        RATING_CHOICES = [
            (1, '1 - Poor'),
            (2, '2 - Below Average'),
            (3, '3 - Average'),
            (4, '4 - Good'),
            (5, '5 - Excellent')
        ]
        
        # Add rating fields for each subject and question
        for subject in subjects:
            for q_num in range(1, 12):  # For 11 questions
                field_name = f'{subject}_q{q_num}'
                self.fields[field_name] = forms.ChoiceField(
                    choices=RATING_CHOICES,
                    widget=forms.Select(attrs={
                        'class': 'rating-select form-control',
                        'required': 'required'
                    }),
                    label=f'Q{q_num}',
                    help_text='Select rating 1-5'
                )
        
        # Add suggestion field
        self.fields['suggestion'] = forms.CharField(
            widget=forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Your suggestions for improvement...'
            }),
            required=False,
            label='Additional Suggestions'
        )
        
    def clean(self):
        cleaned_data = super().clean()
        # You can add any custom validation here if needed
        return cleaned_data