from django.shortcuts import render, redirect
from .forms import SectionForm, FeedbackForm
from .models import Feedback

QUESTIONS = [
    (1, "How much of the syllabus was covered in the class?"),
    (2, "How well did the teacher prepare for the classes?"),
    (3, "How well was the teacher able to communicate?"),
    (4, "The teacher's approach to teaching"),
    (5, "Fairness of the evaluation process"),
    (6, "Teacher informs you about expected competencies"),
    (7, "Teacher illustrates concepts through examples"),
    (8, "Teacher identifies your strengths"),
    (9, "Teacher helps overcome weaknesses"),
    (10, "Encourages extracurricular activities"),
    (11, "Overall quality of teaching-learning process")
]

def select_section(request):
    if request.method == 'POST':
        form = SectionForm(request.POST)
        if form.is_valid():
            section = form.cleaned_data['section']
            return redirect('feedback:give_feedback', section=section)
    else:
        form = SectionForm()
    
    return render(request, 'feedback/select_section.html', {
        'form': form,
        'sections': Feedback.SECTION_CHOICES
    })

def give_feedback(request, section):
    branch = section.split('-')[0] if '-' in section else section
    subjects = Feedback.SUBJECTS.get(branch, [])
    
    if request.method == 'POST':
        form = FeedbackForm(subjects, request.POST)
        if form.is_valid():
            # Process the ratings data
            ratings = {}
            for subject in subjects:
                subject_ratings = {}
                for q_num, _ in QUESTIONS:
                    field_name = f'{subject}_q{q_num}'
                    subject_ratings[f'q{q_num}'] = int(form.cleaned_data[field_name])
                ratings[subject] = subject_ratings
            
            # Save feedback to database
            Feedback.objects.create(
                section=section,
                ratings=ratings,
                suggestion=form.cleaned_data.get('suggestion', '')
            )
            return redirect('feedback:thank_you')
    else:
        form = FeedbackForm(subjects)
    
    return render(request, 'feedback/feedback_form.html', {
        'form': form,
        'section': section,
        'subjects': subjects,
        'questions': QUESTIONS
    })

def thank_you(request):
    return render(request, 'feedback/thank_you.html')