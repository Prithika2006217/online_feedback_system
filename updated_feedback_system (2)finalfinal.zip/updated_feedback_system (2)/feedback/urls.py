from django.urls import path
from . import views

app_name = 'feedback'

urlpatterns = [
    path('', views.select_section, name='select_section'),
    path('section/<str:section>/', views.give_feedback, name='give_feedback'),
    path('thank-you/', views.thank_you, name='thank_you'),
]